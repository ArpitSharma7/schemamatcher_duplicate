from pyspark.sql.types import StringType, StructField, StructType, IntegerType

PART_BY = 2

SCHEMA = StructType([
    StructField('id', IntegerType()),
    StructField('column', StringType()),
    StructField('column_name_length', IntegerType())
])

